from django.apps import AppConfig


class UsersystemConfig(AppConfig):
    name = 'UserSystem'
